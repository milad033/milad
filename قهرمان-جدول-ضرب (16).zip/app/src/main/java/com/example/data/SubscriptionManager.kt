package com.example.data

import android.content.Context
import android.os.SystemClock
import android.util.Log
import ir.cafebazaar.poolakey.Payment
import ir.cafebazaar.poolakey.entity.PurchaseInfo

object SubscriptionManager {
    private const val TAG = "SubscriptionManager"
    private const val PREFS_NAME = "game_license_pref"

    // Secure Time Storage Keys
    private const val KEY_LAST_KNOWN_TIME = "secure_last_known_time"
    private const val KEY_LAST_ELAPSED_REALTIME = "secure_last_elapsed_realtime"

    // Subscription Info Keys
    private const val KEY_SUBSCRIPTION_ID = "subscriptionId"
    private const val KEY_PURCHASE_TOKEN = "purchaseToken"
    private const val KEY_PURCHASE_TIME = "purchaseTime"
    private const val KEY_EXPIRE_TIME = "expireTime"
    private const val KEY_PLAN_NAME = "planName"
    private const val KEY_LAST_SYNC_TIME = "lastSyncTime"

    // Trial / Permanent Keys
    private const val KEY_FIRST_LAUNCH_TIME = "first_launch_time"
    private const val KEY_PERMANENT_LICENSE_ACTIVATED = "permanent_license_activated"

    /**
     * Gets a secure time estimate that is resilient to device clock tampering.
     * It uses the monotonic clock (elapsedRealtime) when possible to track true time progression.
     */
    @Synchronized
    fun getSecureCurrentTime(context: Context): Long {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lastKnownTime = prefs.getLong(KEY_LAST_KNOWN_TIME, 0L)
        val lastElapsed = prefs.getLong(KEY_LAST_ELAPSED_REALTIME, 0L)
        val systemTime = System.currentTimeMillis()
        val elapsedRealtime = SystemClock.elapsedRealtime()

        if (lastKnownTime == 0L) {
            // Initialize for the first time
            prefs.edit()
                .putLong(KEY_LAST_KNOWN_TIME, systemTime)
                .putLong(KEY_LAST_ELAPSED_REALTIME, elapsedRealtime)
                .apply()
            return systemTime
        }

        val elapsedDelta = elapsedRealtime - lastElapsed
        val secureTime = if (elapsedDelta > 0 && lastElapsed > 0) {
            // If the device wasn't rebooted, we trust the elapsedRealtime delta 100%!
            lastKnownTime + elapsedDelta
        } else {
            // Reboot occurred or delta is invalid. Fall back to system time, but never go backward.
            if (systemTime > lastKnownTime) {
                // If system time has moved forward, we use it, but to protect against extreme jumps forward,
                // we can accept it (since going forward makes trial/subscription expire earlier, and they
                // can't bypass anything by jumping forward). But moving clock backward is strictly ignored.
                systemTime
            } else {
                lastKnownTime
            }
        }

        // Always save the latest secure state
        prefs.edit()
            .putLong(KEY_LAST_KNOWN_TIME, secureTime)
            .putLong(KEY_LAST_ELAPSED_REALTIME, elapsedRealtime)
            .apply()

        return secureTime
    }

    /**
     * Initializes the first launch time securely.
     */
    fun initFirstLaunchIfNeeded(context: Context): Long {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        var firstLaunch = prefs.getLong(KEY_FIRST_LAUNCH_TIME, 0L)
        if (firstLaunch == 0L) {
            firstLaunch = getSecureCurrentTime(context)
            prefs.edit().putLong(KEY_FIRST_LAUNCH_TIME, firstLaunch).apply()
            Log.d(TAG, "First launch initialized at: $firstLaunch")
        }
        return firstLaunch
    }

    fun getFirstLaunchTime(context: Context): Long {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val firstLaunch = prefs.getLong(KEY_FIRST_LAUNCH_TIME, 0L)
        return if (firstLaunch == 0L) initFirstLaunchIfNeeded(context) else firstLaunch
    }

    /**
     * Returns true if permanent license is activated via offline activation codes.
     */
    fun isPermanentLicensed(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_PERMANENT_LICENSE_ACTIVATED, false)
    }

    fun setPermanentLicensed(context: Context, activated: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_PERMANENT_LICENSE_ACTIVATED, activated)
            .apply()
    }

    /**
     * Records permanent license via offline activation codes.
     */
    fun recordPermanentActivationCode(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_PERMANENT_LICENSE_ACTIVATED, true)
            .remove(KEY_SUBSCRIPTION_ID)
            .remove(KEY_PURCHASE_TOKEN)
            .remove(KEY_PURCHASE_TIME)
            .remove(KEY_EXPIRE_TIME)
            .remove(KEY_PLAN_NAME)
            .remove(KEY_LAST_SYNC_TIME)
            .apply()
    }

    /**
     * Records a timed license via offline activation codes.
     */
    fun recordTimedActivationCode(context: Context, days: Int) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val currentExp = prefs.getLong(KEY_EXPIRE_TIME, 0L)
        val secureNow = getSecureCurrentTime(context)
        val base = if (currentExp > secureNow) currentExp else secureNow
        val newExp = base + (days * 24L * 60L * 60L * 1000L)

        prefs.edit()
            .putString(KEY_SUBSCRIPTION_ID, "activation_code_$days")
            .putString(KEY_PURCHASE_TOKEN, "activated")
            .putLong(KEY_PURCHASE_TIME, secureNow)
            .putLong(KEY_EXPIRE_TIME, newExp)
            .putString(KEY_PLAN_NAME, "کد فعال‌سازی $days روزه")
            .putLong(KEY_LAST_SYNC_TIME, secureNow)
            .putBoolean(KEY_PERMANENT_LICENSE_ACTIVATED, false)
            .apply()
    }

    /**
     * Updates subscription status when a purchase is successful.
     */
    fun recordPurchase(context: Context, productId: String, purchaseToken: String, purchaseTime: Long) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val days = when (productId) {
            "sub_1month" -> 30
            "sub_3month" -> 90
            "sub_6month" -> 180
            "sub_1year" -> 365
            else -> 30
        }
        val planName = when (productId) {
            "sub_1month" -> "اشتراک ۱ ماهه"
            "sub_3month" -> "اشتراک ۳ ماهه"
            "sub_6month" -> "اشتراک ۶ ماهه"
            "sub_1year" -> "اشتراک ۱ ساله"
            else -> "اشتراک ویژه"
        }

        val durationMs = days * 24L * 60L * 60L * 1000L
        val secureNow = getSecureCurrentTime(context)
        
        // Expiration is based on the purchaseTime returned from Bazaar + duration
        val expireTime = purchaseTime + durationMs

        prefs.edit()
            .putString(KEY_SUBSCRIPTION_ID, productId)
            .putString(KEY_PURCHASE_TOKEN, purchaseToken)
            .putLong(KEY_PURCHASE_TIME, purchaseTime)
            .putLong(KEY_EXPIRE_TIME, expireTime)
            .putString(KEY_PLAN_NAME, planName)
            .putLong(KEY_LAST_SYNC_TIME, secureNow)
            .apply()

        Log.d(TAG, "Recorded purchase: $productId, expires at: $expireTime")
    }

    /**
     * Gets stored subscription details.
     */
    fun getSubscriptionDetails(context: Context): Map<String, Any> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return mapOf(
            "subscriptionId" to (prefs.getString(KEY_SUBSCRIPTION_ID, "") ?: ""),
            "purchaseToken" to (prefs.getString(KEY_PURCHASE_TOKEN, "") ?: ""),
            "purchaseTime" to prefs.getLong(KEY_PURCHASE_TIME, 0L),
            "expireTime" to prefs.getLong(KEY_EXPIRE_TIME, 0L),
            "planName" to (prefs.getString(KEY_PLAN_NAME, "") ?: ""),
            "lastSyncTime" to prefs.getLong(KEY_LAST_SYNC_TIME, 0L)
        )
    }

    /**
     * Clears local subscription records.
     */
    fun clearSubscriptionDetails(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .remove(KEY_SUBSCRIPTION_ID)
            .remove(KEY_PURCHASE_TOKEN)
            .remove(KEY_PURCHASE_TIME)
            .remove(KEY_EXPIRE_TIME)
            .remove(KEY_PLAN_NAME)
            .remove(KEY_LAST_SYNC_TIME)
            .apply()
    }

    /**
     * Synchronizes active subscriptions with Café Bazaar.
     */
    fun syncSubscription(context: Context, payment: Payment, onComplete: (Boolean) -> Unit = {}) {
        Log.d(TAG, "SyncSubscription() started...")
        payment.getSubscribedProducts {
            querySucceed { purchasedProducts ->
                val activeSub = purchasedProducts.find {
                    it.productId in listOf("sub_1month", "sub_3month", "sub_6month", "sub_1year")
                }
                val secureNow = getSecureCurrentTime(context)
                if (activeSub != null) {
                    Log.d(TAG, "Active subscription found on Cafe Bazaar: ${activeSub.productId}")
                    recordPurchase(
                        context = context,
                        productId = activeSub.productId,
                        purchaseToken = activeSub.purchaseToken ?: "",
                        purchaseTime = activeSub.purchaseTime
                    )
                    onComplete(true)
                } else {
                    Log.d(TAG, "No active subscription found on Cafe Bazaar.")
                    // If we previously had a subscription locally but Café Bazaar returns no active subscription,
                    // we should clear or invalidate it so it reflects the actual Café Bazaar state.
                    clearSubscriptionDetails(context)
                    onComplete(false)
                }
            }
            queryFailed { errorStatus ->
                Log.w(TAG, "Failed to query subscriptions from Bazaar: ${errorStatus.message}")
                onComplete(false)
            }
        }
    }

    /**
     * Checks if the license/subscription/trial has expired.
     */
    fun isLicenseExpired(context: Context): Boolean {
        if (isPermanentLicensed(context)) {
            return false
        }

        val secureNow = getSecureCurrentTime(context)
        val details = getSubscriptionDetails(context)
        val expireTime = details["expireTime"] as Long

        if (expireTime > 0L) {
            // Subscription is active if secureNow is less than expireTime
            val expired = secureNow >= expireTime
            if (expired) {
                Log.d(TAG, "Subscription is expired. SecureNow: $secureNow, ExpireTime: $expireTime")
            }
            return expired
        }

        // If no subscription is active, verify the 3-day trial period
        val firstLaunch = getFirstLaunchTime(context)
        val trialDurationMs = 3L * 24L * 60L * 60L * 1000L
        val elapsed = secureNow - firstLaunch
        val trialExpired = elapsed >= trialDurationMs
        
        if (trialExpired) {
            Log.d(TAG, "Trial is expired. SecureNow: $secureNow, FirstLaunch: $firstLaunch, Elapsed: $elapsed")
        }
        return trialExpired
    }

    /**
     * Calculates the remaining time of active subscription or trial in milliseconds.
     */
    fun getRemainingTimeMs(context: Context): Long {
        if (isPermanentLicensed(context)) {
            return Long.MAX_VALUE
        }

        val secureNow = getSecureCurrentTime(context)
        val details = getSubscriptionDetails(context)
        val expireTime = details["expireTime"] as Long

        if (expireTime > 0L) {
            return (expireTime - secureNow).coerceAtLeast(0L)
        }

        // 3-day trial
        val firstLaunch = getFirstLaunchTime(context)
        val trialDurationMs = 3L * 24L * 60L * 60L * 1000L
        val elapsed = secureNow - firstLaunch
        return (trialDurationMs - elapsed).coerceAtLeast(0L)
    }
}
